﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 from2 = new Form2();
            from2.Tag = this;
            from2.Show();
            Hide();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Tab)
            {
                Form3 f = new Form3();
                this.Hide();
                f.ShowDialog();
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private int modifX()
        {
            int rdmx;
            int x_max = this.Width;
            Random rdm = new Random();
            rdmx = rdm.Next(0, x_max);
            return rdmx;
        }

        private int ModifY()
        {
            int rdmx;
            int x_max = this.Width;
            Random rdm = new Random();
            rdmx = rdm.Next(0, x_max);
            return rdmx;
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.Location = new Point(modifX(), ModifY());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
